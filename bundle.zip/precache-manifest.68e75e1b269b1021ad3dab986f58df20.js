self.__precacheManifest = [
  {
    "revision": "38121eb9b2a7b7f77c3b",
    "url": "/static/css/main.2e07a0aa.chunk.css"
  },
  {
    "revision": "38121eb9b2a7b7f77c3b",
    "url": "/static/js/main.8c87a44e.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "574b1f516789537b28ad",
    "url": "/static/css/2.e39c82e7.chunk.css"
  },
  {
    "revision": "574b1f516789537b28ad",
    "url": "/static/js/2.ae6254e1.chunk.js"
  },
  {
    "revision": "55090e7e05826cb920757f08e69cd51d",
    "url": "/index.html"
  }
];